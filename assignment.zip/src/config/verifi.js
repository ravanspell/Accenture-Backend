/**
 * verifijs is java script data validation library
 * written & published by myself
 */
import VerifiJs from 'verifijs';

const validation = new VerifiJs();
validation.setBailAll(true);
export default validation;
