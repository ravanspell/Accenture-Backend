import { TeacherModal } from '../models/index.js';

class TeacherRepository {
  constructor() {
    this.create = this.create.bind(this);
    this.get = this.get.bind(this);
    this.teacherModal = TeacherModal;
  }

  create(data) {
    return this.teacherModal.create(data);
  }

  get(params) {
    return this.teacherModal.findAndCountAll(params);
  }
}

export default new TeacherRepository();
