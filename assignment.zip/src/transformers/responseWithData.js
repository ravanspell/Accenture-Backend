const responseWithData = (data) => ({
  data,
});

export default responseWithData;
