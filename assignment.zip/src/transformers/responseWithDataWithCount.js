const responseWithDataWithCount = (data, count) => ({
  data,
  count,
});

export default responseWithDataWithCount;
