import ClassRepository from '../repositories/class.repository.js';

class ClassService {
  constructor() {
    this.createClass = this.createClass.bind(this);
    this.classRepository = ClassRepository;
  }

  async createClass(data) {
    const response = await this.classRepository.create(data);
    return response;
  }

  async fetchClasses(params) {
    const page = params?.page_number;
    // set default page size to avoid to get all data once.
    const limit = params?.page_size || process.env.DEFAULT_PAGE_DATA_RETURN_SIZE;

    const pageOffset = page ? (page - 1) * limit : null;
    const pageLimit = limit ? parseInt(limit, 10) : null;

    const fetchParams = {
      limit: pageLimit,
      offset: pageOffset,
    };
    const data = await this.classRepository.getWithTeacher(fetchParams);
    return data;
  }
}

export default new ClassService();
