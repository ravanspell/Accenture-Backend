export { default as teacherController } from './teacher.controller.js';
export { default as classController } from './class.controller.js';
